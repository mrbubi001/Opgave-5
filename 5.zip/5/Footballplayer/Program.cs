﻿using System;

namespace Footballplayer
{
        public class Program
        {
            public int Id { get; set; }
            private string _name;
            private int _price;
            private int _shirtNumber;

            public string Name
            {
                get { return _name; }
                set
                {
                    if (String.IsNullOrEmpty(value)) throw new ArgumentException();
                    _name = value;
                }
            }

            public int Price
            {
                get { return _price; }
                set
                {
                    if (value <= 0) throw new ArgumentOutOfRangeException();
                    _price = value;
                }
            }   

            public int ShirtNumber
            {
                get { return _shirtNumber; }
                set
                {
                    if (value < 1 || value > 100) throw new ArgumentOutOfRangeException();
                    _shirtNumber = value;
                }
            }

            public Program(int id, string name, int price, int shirtNumber)
            {
                Id = id;
                Name = name;
                Price = price;
                ShirtNumber = shirtNumber;
            }

            public override string ToString()
            {
                return $"ID: {Id}: Player: {Name} Number: {ShirtNumber} Price: {Price}";
            }
        }
    }
