﻿using Footballplayer;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Opgave5Server
{
    public class Server
    {
        public static List<Program> player = new List<Program>() {
            new Program(1, "Messi", 100, 10),
            new Program(2, "Neymar", 200, 5),
            new Program(3, "Patrick", 300, 1)
        };


        public Server()
        {

        }

        public void Start()
        {
            TcpListener listener = new TcpListener(IPAddress.Loopback, 2121);
            listener.Start();

            while (true)
            {
                TcpClient tempSocket = listener.AcceptTcpClient();
                Task.Run(() => DoClient(tempSocket));
            }
        }



        private void DoClient(TcpClient socket)
        {
            using (StreamReader sr = new StreamReader(socket.GetStream()))
            using (StreamWriter sw = new StreamWriter(socket.GetStream()))
            {
                string readLine1 = sr.ReadLine();
                string readline2 = sr.ReadLine();

                if(readLine1 == "HentAlle")
                {
                    string output = GetAll();
                    sw.WriteLine(output);
                    Console.WriteLine(output);
                }
                else if (readLine1 == "Hent")
                {
                    string output2 = GetPlayer(readline2);
                    sw.WriteLine(output2);
                    Console.WriteLine(output2);
                }
                else if (readLine1 == "Gem") 
                {
                    string output3 = SavePlayer(readline2);
                    sw.WriteLine(output3);
                    Console.WriteLine(output3);
                }
             }
        }

        private string GetAll()
        {
            return JsonSerializer.Serialize<List<Program>>(player);
        }

        private string GetPlayer(int id)
        {
            Program players = player.Find(p => p.Id == id);
            return JsonSerializer.Serialize<List<Program>>(players);
        }

        private void SavePlayer(string readline2)
        {
            player.Add(JsonSerializer.Deserialize<Program>(readline2));
        }
    }
}
